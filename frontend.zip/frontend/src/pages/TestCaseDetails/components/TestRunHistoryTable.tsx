import { History, Calendar, Clock, ChevronRight, CheckCircle2, XCircle, AlertCircle, StopCircle, AlertTriangle } from 'lucide-react';
import { TestCaseRun } from '@/types/run';
import { parseUTCDate } from '@/utils/formatters';

interface TestRunHistoryTableProps {
    history: TestCaseRun[];
    projectId: string;
    onRunClick: (run: TestCaseRun) => void;
}

export const TestRunHistoryTable: React.FC<TestRunHistoryTableProps> = ({ history, onRunClick }) => {
    const getStatusStyles = (status?: string) => {
        const s = status?.toUpperCase();
        switch (s) {
            case 'PASSED':
            case 'SUCCESS':
            case 'EXECUTED':
                return {
                    icon: <CheckCircle2 className="w-4 h-4" />,
                    bg: 'bg-emerald-50 text-emerald-600 border-emerald-100',
                    dot: 'bg-emerald-500'
                };
            case 'FAILED':
            case 'FAILURE':
                return {
                    icon: <XCircle className="w-4 h-4" />,
                    bg: 'bg-rose-50 text-rose-600 border-rose-100',
                    dot: 'bg-rose-500'
                };
            case 'ABORTED':
                return {
                    icon: <StopCircle className="w-4 h-4" />,
                    bg: 'bg-slate-100 text-slate-600 border-slate-200',
                    dot: 'bg-slate-500'
                };
            case 'ERROR':
                return {
                    icon: <AlertTriangle className="w-4 h-4" />,
                    bg: 'bg-amber-50 text-amber-600 border-amber-100',
                    dot: 'bg-amber-500'
                };
            default:
                return {
                    icon: <AlertCircle className="w-4 h-4" />,
                    bg: 'bg-blue-50 text-blue-600 border-blue-100',
                    dot: 'bg-blue-500'
                };
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between px-2">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                        <History className="w-5 h-5 text-primary" />
                    </div>
                    <h2 className="text-xl font-black text-gray-900 tracking-tight capitalize">Run History</h2>
                </div>
                <div className="text-[10px] font-black text-gray-400 capitalize tracking-widest">
                    Last {history.length} executions
                </div>
            </div>

            <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden transition-all duration-500">
                <table className="w-full">
                    <thead className="bg-gray-50/50 border-b border-gray-100">
                        <tr>
                            <th className="px-8 py-5 text-left text-[10px] font-black text-gray-400 capitalize tracking-widest">
                                Run Identity
                            </th>
                            <th className="px-8 py-5 text-center text-[10px] font-black text-gray-400 capitalize tracking-widest">
                                Status
                            </th>
                            <th className="px-8 py-5 text-center text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">
                                Execution Timeline
                            </th>
                            <th className="px-8 py-5 text-center text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">
                                Duration
                            </th>
                            <th className="px-8 py-5 text-right text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                        {history.map((run) => (
                            <tr
                                key={run.id}
                                onClick={() => onRunClick(run)}
                                className="hover:bg-gray-50/50 cursor-pointer transition-all group"
                            >
                                <td className="px-8 py-6">
                                    <div className="flex items-center gap-4">
                                        <div className="w-12 h-12 rounded-2xl bg-gray-50 border border-gray-100 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-300">
                                            <History className="w-6 h-6 text-gray-400 group-hover:text-primary transition-colors" />
                                        </div>
                                        <div className="flex flex-col">
                                            <span className="text-sm font-black text-gray-900 group-hover:text-primary transition-all">
                                                Run #{run.id}
                                            </span>
                                        </div>
                                    </div>
                                </td>
                                <td className="px-8 py-6 text-center">
                                    {(() => {
                                        const styles = getStatusStyles(run.status);
                                        return (
                                            <div className={`flex items-center justify-center gap-2 px-3 py-1.5 rounded-full border shadow-sm mx-auto w-fit transition-all ${styles.bg}`}>
                                                {styles.icon}
                                                <span className="text-[10px] font-black uppercase tracking-wider">
                                                    {run.status}
                                                </span>
                                            </div>
                                        );
                                    })()}
                                </td>
                                <td className="px-8 py-6 text-center">
                                    <div className="flex flex-col items-center gap-1">
                                        <div className="flex items-center gap-2 text-[11px] font-black text-gray-700">
                                            <Calendar className="w-3.5 h-3.5 text-gray-400" />
                                            {(() => {
                                                const dateStr = run.started_at || run.created_at;
                                                const date = parseUTCDate(dateStr);
                                                return date?.toLocaleDateString([], { month: 'short', day: 'numeric' }) || '-';
                                            })()}
                                        </div>
                                        <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400">
                                            <Clock className="w-3.5 h-3.5" />
                                            {(() => {
                                                if (!run.started_at) return 'Pending';
                                                const date = parseUTCDate(run.started_at);
                                                return date?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) || '-';
                                            })()}
                                        </div>
                                    </div>
                                </td>
                                <td className="px-8 py-6 text-center">
                                    <span className="text-xs font-black text-gray-500 tabular-nums">
                                        {(() => {
                                            const start = parseUTCDate(run.started_at);
                                            const finish = parseUTCDate(run.finished_at);
                                            if (start && finish) {
                                                const durationSeconds = Math.floor((finish.getTime() - start.getTime()) / 1000);
                                                return durationSeconds > 60
                                                    ? `${Math.floor(durationSeconds / 60)}m ${durationSeconds % 60}s`
                                                    : `${durationSeconds}s`;
                                            } else if (start && run.status === 'RUNNING') {
                                                return 'In progress...';
                                            }
                                            return '-';
                                        })()}
                                    </span>
                                </td>
                                <td className="px-8 py-6 text-right">
                                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-4 group-hover:translate-x-0">
                                        <div className="w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center text-gray-400 group-hover:text-primary group-hover:bg-primary/10 transition-all">
                                            <ChevronRight className="w-5 h-5" />
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
